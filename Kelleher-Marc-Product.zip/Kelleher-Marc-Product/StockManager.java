import java.util.ArrayList;

/**
 * Manage the stock in a business.
 * The stock is described by zero or more Products.
 * 
 * @author Marc Kelleher 
 * @version 1.0  8/13/2015
 * 
 * Completed the methods printProductDetails, findProduct, numberInStock and delivery.
 */
public class StockManager
{
    // A list of the products.
    private ArrayList<Product> stock;

    /**
     * Initialise the stock manager.
     */
    public StockManager()
    {
        stock = new ArrayList<Product>();
    }

    /**
     * Add a product to the list.
     * @param item The item to be added.
     */
    public void addProduct(Product item)
    {
        stock.add(item);
    }
    
    /**
     * @author Marc Kelleher
     * Method: delivery 
     * 
     * Receive a delivery of a particular product.
     * Increase the quantity of the product by the given amount.
     * @param id The ID of the product.
     * @param amount The amount to increase the quantity by.
     */
    public void delivery(int id, int amount)
    {
        if(findProduct(id) != null)
        {
           findProduct(id).increaseQuantity(amount);
        }
        else
        {
            System.out.println("Delivery amount could not be added.");
        }
    }
    
    /**
     * @author Marc Kelleher
     * Method: findProduct 
     * 
     * Try to find a product in the stock with the given id.
     * @return The identified product, or null if there is none
     *         with a matching ID.
     */
    public Product findProduct(int id)
    {
        Product selectedProduct = null;
        int index = 0;
        boolean searching = true;
        boolean productExists = false;
        if((id >= 1))// && (id < stock.size()))
        {
            while(searching && index < stock.size())
            {
                if(stock.get(index).getID() == id)
                {
                    selectedProduct = stock.get(index);
                    productExists = true;
                    break; // The product was found, leave the loop.
                }
                else
                {
                    //keep searching.
                    index++;
                }
            }
            if(productExists)
            {
                return selectedProduct;
            }
            else
            {
                // The product id does not exist.
                System.out.println("Product number " + id + " does not exist.");
                return null;
            }
        }
        else 
        {
             // The product id does not exist.
             System.out.println("Please enter a positive integer value.");
             return null;
        }
    }
    
    /**
     * @author Marc Kelleher
     * Method: numberInStock 
     * 
     * Locate a product with the given ID, and return how
     * many of this item are in stock. If the ID does not
     * match any product, return zero.
     * @param id The ID number of the product.
     * @return The quantity of the given product in stock or 0 if the product doesn't exist.
     */
    public int numberInStock(int id)
    {
        int amountInStock = 0;
        if(findProduct(id) != null)
        {
        amountInStock = findProduct(id).getQuantity(); 
        return amountInStock;
        }
        else
        {
            return 0;
        }
    }

    /**
     * @author Marc Kelleher
     * Method: printProductDetails
     * 
     * Print details of all the products.
     */
    public void printProductDetails()
    {
        for(Product product : stock)
        {
            System.out.println(product.toString());
        }
    }
}
